from django.shortcuts import render
from .models import Post
# Create your views here.
def index(request):
    posts = Post.objects.all()
    context = {
        "posts": posts,
    }
    return render(request, 'blogapp/index.html', context)
def film(request, postid):
    # pk это номер фильма.
    film = Post.objects.get(pk=postid)
    context = {
        "film": film,
    }
    return render(request, 'blogapp/film.html', context)