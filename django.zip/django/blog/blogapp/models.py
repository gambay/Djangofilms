from django.db import models

# Create your models here.
class Post(models.Model):
    img = models.ImageField(upload_to = 'images/')
    name = models.CharField(max_length = 50, default = '')
    description = models.CharField(max_length = 200, default = '')
    rating = models.IntegerField(blank = True, null = True)
    director = models.CharField(max_length = 100, default = '')
    actors = models.CharField(max_length = 100, default = '')